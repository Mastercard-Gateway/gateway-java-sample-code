/*
 * Copyright (c) 2019 MasterCard. All rights reserved.
 */

package com.gateway.app;

import com.gateway.client.ApiRequest;
import com.gateway.client.ApiRequestService;
import com.gateway.client.ApiResponseService;
import com.gateway.client.RESTApiClient;
import com.gateway.response.TransactionResponse;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import static com.gateway.client.ApiOperation.AUTHORIZE;
import static org.hamcrest.Matchers.containsString;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@RunWith(SpringRunner.class)
@WebMvcTest(ApiControllerTest.class)
public class ApiControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ApiRequestService apiRequestService;
    @MockBean
    private ApiResponseService apiResponseService;

    private RESTApiClient client;

    private Config config;

    @Before
    public void setUp() {
        config = new Config();
        config.setMerchantId("TESTMERCHANTID");
        config.setApiPassword("APIPASSWORD1234");
        config.setApiBaseURL("https://test-gateway.com");
        config.setGatewayHost("https://test-gateway.com");
        config.setCurrency("USD");
        config.setApiVersion(51);

        client = new RESTApiClient();
    }

    @Test
    public void process3ds2RedirectShouldShowReceipt() throws Exception {
//        final ApiRequest mockApiRequest = new ApiRequest().setApiOperation(ApiOperation.AUTHORIZE).setApiMethod("PUT");
        final String jSONPayload = "{\n" +
                "  \"apiOperation\": \"AUTHORIZE\",\n" +
                "  \"order\": {\n" +
                "    \"amount\": \"5000\",\n" +
                "    \"currency\": \"USD\"\n" +
                "  },\n" +
                "  \"sourceOfFunds\": {\n" +
                "    \"type\": \"CARD\"\n" +
                "  },\n" +
                "  \"session\": {\n" +
                "    \"id\": \"SESSION0002164388937F89865099L3\"\n" +
                "  }\n" +
                "}";
        final String sendTransactionResponse =
                "{\"authorizationResponse\":{" +
                        "\"autoExpiry\":\"2019-03-28T00:00:00Z\"," +
                        "\"posData\":\"1605S0100130\"," +
                        "\"transactionIdentifier\":\"AmexTidTest\"}," +
                        "\"device\":{\"browser\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.80 Safari/537.36\"," +
                        "\"ipAddress\":\"192.168.254.17\"},\"gatewayEntryPoint\":\"WEB_SERVICES_API\"," +
                        "\"merchant\":\"TESTWTF_3DS\",\"order\":{\"amount\":5000.00,\"chargeback\":{" +
                        "\"amount\":0,\"currency\":\"USD\"},\"creationTime\":\"2019-02-26T00:13:23.771Z\"," +
                        "\"currency\":\"USD\",\"id\":\"order-Qn4sBXNgEK\",\"merchantCategoryCode\":\"4567\"," +
                        "\"status\":\"AUTHORIZED\",\"totalAuthorizedAmount\":5000.00,\"totalCapturedAmount\":0.00," +
                        "\"totalRefundedAmount\":0.00},\"response\":{\"acquirerCode\":\"00\",\"cardSecurityCode\":{" +
                        "\"acquirerCode\":\"M\",\"gatewayCode\":\"MATCH\"},\"gatewayCode\":\"APPROVED\"}," +
                        "\"result\":\"SUCCESS\",\"sourceOfFunds\":{\"provided\":{\"card\":{\"brand\":\"MASTERCARD\"," +
                        "\"expiry\":{\"month\":\"5\",\"year\":\"21\"},\"fundingMethod\":\"CREDIT\"," +
                        "\"issuer\":\"BANCO DEL PICHINCHA, C.A.\",\"number\":\"512345xxxxxx0008\"," +
                        "\"scheme\":\"MASTERCARD\",\"storedOnFile\":\"NOT_STORED\"}},\"type\":\"CARD\"}," +
                        "\"timeOfRecord\":\"2019-02-26T00:13:23.771Z\",\"transaction\":{\"acquirer\":{\"batch\":1," +
                        "\"id\":\"SYSTEST_ACQ1\",\"merchantId\":\"9625635149\"},\"amount\":5000.00," +
                        "\"authorizationCode\":\"000112\",\"currency\":\"USD\",\"frequency\":\"SINGLE\"," +
                        "\"id\":\"trans-IH56oQkSgp\",\"receipt\":\"190226110\",\"source\":\"CALL_CENTRE\"," +
                        "\"terminal\":\"001\",\"type\":\"AUTHORIZATION\"},\"version\":\"51\"}";
//        when(apiRequestService.createApiRequest(any(String.class), config))
//                .thenReturn(mockApiRequest);
        when(apiRequestService.buildJSONPayload(any(ApiRequest.class))).thenReturn(jSONPayload);

        when(client.sendTransaction(any(String.class), any(String.class), any(Config.class)))
                .thenReturn(sendTransactionResponse);

//        when(apiResponseService.parseAuthorizeResponse(any(String.class))).thenReturn(mock(TransactionResponse.class));
        String formData =
                "order.id=order-Qn4sBXNgEK&transaction.id=trans-IH56oQkSgp&response.gatewayRecommendation=PROCEED_WITH_PAYMENT&encryptedData.ciphertext=xMfnuBlIKZC4m7TFFi499rqV%2FqRxfG%2FXmyRsWUh7J%2Fmar2M2%2Fo7IcqFMBmlQQyzvpqTRwtmh%2FOT7HzRbBNPDLPdTsZnPt5%2FAkMKPbCnMjlCwtsUV8ArnWgE8GWQunM9%2FqTgB9HuEW5cGZFxeWV84lgrYhjswgJ2VYougiVO13g1dWJF99JqzXqwjfv8Af%2B%2FSNXMlbJ79QDGtEKl5IPFde3sywZ8%2F8XrCr8Mdusxk0BiG3B2dKIIKOb9NAKaKqKMT8A9y1wO6ec1fTMH6zT5NinM73DCFOE3YTbC1dAqZB2BcE%2FLKs7SzUOfQirLx2ZvUDpxfrs3zVKiwu4aHK9UOZBrSWYkZgV2EVJZD9yqIRMFUn6By%2FjJSWTQG56DqPijNl5ayR4RizaO0EB%2Bai2DsocU1D1kH62RrPBD99I4b4tdzbG0d1H7UfhblVzISHOEZx39QqxnHq7%2FLTblSsgTv38f7SHyxBTLu%2BRQ%3D&encryptedData.nonce=AjQOXFsqn%2BOAAACo&encryptedData.tag=xgbuEZNH8yW6S7CJuUuDSg%3D%3D&result=SUCCESS";
//        String queryParams =
//                "merchantId=TESTWTF_3DS&sessionId=SESSION0002164388937F89865099L3";
        this.mockMvc.perform(post("/process3ds2Redirect")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED_VALUE)
                .content(formData)
                .param("merchantId", "TESTWTF_3DS").param("sessionId", "SESSION0002164388937F89865099L3"))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Payment complete!")));
    }


}