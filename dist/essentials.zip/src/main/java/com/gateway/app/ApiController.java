package com.gateway.app;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gateway.client.*;
import com.gateway.response.BrowserPaymentResponse;
import com.gateway.response.SecureIdEnrollmentResponse;
import com.gateway.response.TransactionResponse;
import com.gateway.response.WalletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Map;

@Controller
public class ApiController {

    private static final Logger logger = LoggerFactory.getLogger(ApiController.class);

    @Autowired
    public Config config;



    /**
     * This method receives the callback from the Hosted Checkout redirect. It looks up the order using the RETRIEVE_ORDER operation and
     * displays either the receipt or an error page.
     *
     * @param orderId needed to retrieve order
     * @param result  of Hosted Checkout operation (success or error) - sent from hostedCheckout.html complete() callback
     * @return ModelAndView for hosted checkout receipt page or error page
     */
    @GetMapping("/hostedCheckout/{orderId}/{result}")
    public ModelAndView hostedCheckoutReceipt(@PathVariable(value = "orderId") String orderId, @PathVariable(value = "result") String result) {

        ModelAndView mav = new ModelAndView();

        try {
            if (result.equals(ApiResponses.SUCCESS.toString())) {
                ApiRequest req = new ApiRequest();
                req.setApiOperation("RETRIEVE_ORDER");
                req.setOrderId(orderId);

                String requestUrl = ApiRequestService.getRequestUrl(ApiProtocol.REST, config, req);

                RESTApiClient connection = new RESTApiClient();
                String resp = connection.getTransaction(requestUrl, config);
                TransactionResponse hostedCheckoutResponse = ApiResponseService.parseHostedCheckoutResponse(resp);

                mav.addObject("response", hostedCheckoutResponse);
                mav.setViewName("receipt");
            } else {
                mav.setViewName("error");
                logger.info("The payment was unsuccessful");
                mav.addObject("cause", "Payment was unsuccessful");
                mav.addObject("message", "There was a problem completing your transaction.");
            }
        }
        catch (ApiException e) {
            ExceptionService.constructApiErrorResponse(mav, e);
        }
        catch (Exception e) {
            ExceptionService.constructGeneralErrorResponse(mav, e);
        }

        return mav;
    }

    @GetMapping("/hostedCheckout/{orderId}/{successIndicator}/{sessionId}")
    ModelAndView hostedCheckoutRedirect(@PathVariable(value = "orderId") String orderId, @PathVariable(value = "successIndicator") String successIndicator, @PathVariable(value = "sessionId") String sessionId) {
        ModelAndView mav = new ModelAndView("hostedCheckout");

        HostedSession hostedSession = new HostedSession();
        hostedSession.setSuccessIndicator(successIndicator);
        hostedSession.setId(sessionId);

        mav.addObject("hostedSession", hostedSession);
        mav.addObject("config", config);
        mav.addObject("orderId", orderId);
        return mav;
    }

    /**
     * This method processes the API request for Hosted Session (browser) operations (PAY, AUTHORIZE, VERIFY).
     * Whenever card details need to be collected from the browser, Hosted Session is the preferred method.
     *
     * @param apiRequest needed to retrieve various data to complete API operation
     * @return ModelAndView for API response page or error page
     */
    @PostMapping("/processHostedSession")
    public ModelAndView processHostedSession(@RequestBody ApiRequest apiRequest) {

        ModelAndView mav = new ModelAndView();

        try {
            ApiRequestService.updateSessionWithOrderInfo(ApiProtocol.REST, apiRequest, config, apiRequest.getSessionId());

            String jsonPayload = ApiRequestService.buildJSONPayload(apiRequest);
            String requestUrl = ApiRequestService.getRequestUrl(ApiProtocol.REST, config, apiRequest);

            // Perform API operation
            RESTApiClient apiConnection = new RESTApiClient();
            String apiResponse = apiConnection.sendTransaction(jsonPayload, requestUrl, config);

            // Format request/response for easy viewing
            ObjectMapper mapper = new ObjectMapper();
            Object prettyResp = mapper.readValue(apiResponse, Object.class);
            Object prettyPayload = mapper.readValue(jsonPayload, Object.class);

            mav.setViewName("apiResponse");
            mav.addObject("config", config);
            mav.addObject("resp", mapper.writerWithDefaultPrettyPrinter().writeValueAsString(prettyResp));
            mav.addObject("operation", apiRequest.getApiOperation());
            mav.addObject("method", apiRequest.getApiMethod());
            mav.addObject("request", mapper.writerWithDefaultPrettyPrinter().writeValueAsString(prettyPayload));
            mav.addObject("requestUrl", requestUrl);
        } catch (ApiException e) {
            ExceptionService.constructApiErrorResponse(mav, e);
        } catch (Exception e) {
            ExceptionService.constructGeneralErrorResponse(mav, e);
        }
        return mav;
    }

    @PostMapping("/tokenize")
    public ModelAndView tokenizeAndPay(@RequestBody ApiRequest tokenRequest) {
        ModelAndView mav = new ModelAndView();

        try {
            ApiRequestService.updateSessionWithOrderInfo(ApiProtocol.REST, tokenRequest, config, tokenRequest.getSessionId());

            String tokenRequestUrl = ApiRequestService.getTokenRequestUrl(ApiProtocol.REST, config);

            // We need to delete the order info from the token request. We'll need it later for the payment request, so we'll add it to the payment request here
            ApiRequest payRequest = new ApiRequest();
            payRequest.setApiOperation("PAY");
            payRequest.setSessionId(tokenRequest.getSessionId());
            payRequest.setOrderId(tokenRequest.getOrderId());
            payRequest.setTransactionId(tokenRequest.getTransactionId());

            // We've already updated the session with the order information, so we need to remove it from the token request, which only requires the session ID (if additional fields are present the API will return an error)
            tokenRequest.setOrderAmount(null);
            tokenRequest.setOrderDescription(null);
            tokenRequest.setOrderCurrency(null);
            tokenRequest.setOrderId(null);

            String tokenPayload = ApiRequestService.buildJSONPayload(tokenRequest);

            RESTApiClient tokenConnection = new RESTApiClient();
            String tokenResponse = tokenConnection.postTransaction(tokenPayload, tokenRequestUrl, config);
            String token = ApiResponseService.parseTokenResponse(tokenResponse);

            payRequest.setSourceToken(token);
            String paymentRequestUrl = ApiRequestService.getRequestUrl(ApiProtocol.REST, config, payRequest);

            String paymentPayload = ApiRequestService.buildJSONPayload(payRequest);
            RESTApiClient paymentConnection = new RESTApiClient();
            String paymentResponse = paymentConnection.sendTransaction(paymentPayload, paymentRequestUrl, config);

            ObjectMapper mapper = new ObjectMapper();
            Object prettyResp = mapper.readValue(paymentResponse, Object.class);
            Object prettyPayload = mapper.readValue(paymentPayload, Object.class);

            mav.setViewName("apiResponse");
            mav.addObject("resp", mapper.writerWithDefaultPrettyPrinter().writeValueAsString(prettyResp));
            mav.addObject("operation", payRequest.getApiOperation());
            mav.addObject("method", payRequest.getApiMethod());
            mav.addObject("request", mapper.writerWithDefaultPrettyPrinter().writeValueAsString(prettyPayload));
            mav.addObject("requestUrl", paymentRequestUrl);
        } catch (ApiException e) {
            ExceptionService.constructApiErrorResponse(mav, e);
        } catch (Exception e) {
            ExceptionService.constructGeneralErrorResponse(mav, e);
        }
        return mav;
    }

    /**
     * This method processes the API request using NVP (Name-Value Pair) protocol for Hosted Session (browser) operations (PAY, AUTHORIZE, VERIFY). Any time card details need to be collected, Hosted Session is the preferred method.
     *
     * @return ModelAndView for api response page or error page
     */
    @PostMapping("/processPayThroughNVP")
    public ModelAndView processNVPHostedSession(@RequestBody ApiRequest apiRequest) {

        ModelAndView mav = new ModelAndView();

        try {
            ApiRequestService.updateSessionWithOrderInfo(ApiProtocol.REST, apiRequest, config, apiRequest.getSessionId());

            apiRequest.setApiMethod("POST");

            String requestUrl = ApiRequestService.getRequestUrl(ApiProtocol.NVP, config, apiRequest);
            Map<String, String> dataMap = ApiRequestService.buildMap(apiRequest);

            NVPApiClient connection = new NVPApiClient();
            String response = connection.postTransaction(dataMap, requestUrl, config);
            Map<String, String> responseMap = ApiResponseService.parseNVPResponse(response);

            mav.setViewName("nvpApiResponse");
            mav.addObject("responseMap", responseMap);
            mav.addObject("operation", apiRequest.getApiOperation());
            mav.addObject("method", apiRequest.getApiMethod());
            mav.addObject("request", dataMap);
            mav.addObject("requestUrl", requestUrl);
        } catch (ApiException e) {
            ExceptionService.constructApiErrorResponse(mav, e);
        } catch (Exception e) {
            ExceptionService.constructGeneralErrorResponse(mav, e);
        }
        return mav;
    }

    /**
     * This method processes the API request for server-to-server operations.
     * These are operations that would not commonly be invoked via a user interacting with the browser, but a system event (CAPTURE, REFUND, VOID).
     *
     * @param request contains info on how to construct API call
     * @return ModelAndView for api response page or error page
     */
    @PostMapping("/process")
    public ModelAndView process(ApiRequest request) {

        ModelAndView mav = new ModelAndView();

        String requestUrl = ApiRequestService.getRequestUrl(ApiProtocol.REST, config, request);
        String jsonPayload = ApiRequestService.buildJSONPayload(request);

        String resp = "";

        try {
            RESTApiClient connection = new RESTApiClient();
            if (request.getApiMethod().equals("PUT")) {
                resp = connection.sendTransaction(jsonPayload, requestUrl, config);
            } else if (request.getApiMethod().equals("GET")) {
                resp = connection.getTransaction(requestUrl, config);
            }
            ObjectMapper mapper = new ObjectMapper();
            Object prettyResp = mapper.readValue(resp, Object.class);
            Object prettyPayload = mapper.readValue(jsonPayload, Object.class);

            mav.setViewName("apiResponse");
            mav.addObject("resp", mapper.writerWithDefaultPrettyPrinter().writeValueAsString(prettyResp));
            mav.addObject("operation", request.getApiOperation());
            mav.addObject("method", request.getApiMethod());
            mav.addObject("request", mapper.writerWithDefaultPrettyPrinter().writeValueAsString(prettyPayload));
            mav.addObject("requestUrl", requestUrl);
        } catch (ApiException e) {
            ExceptionService.constructApiErrorResponse(mav, e);
        } catch (Exception e) {
            ExceptionService.constructGeneralErrorResponse(mav, e);
        }
        return mav;
    }

    /**
     * This method calls the INTIATE_BROWSER_PAYMENT operation, which returns a URL to the provider's website. The user is redirected to this URL, where the purchase is completed.
     *
     * @param request contains info on how to construct API call
     * @return ModelAndView - either redirects to appropriate provider website or returns error page
     */
    @PostMapping("/processBrowserPayment")
    public ModelAndView processBrowserPayment(ApiRequest request) {
        ModelAndView mav = new ModelAndView();

        String requestUrl = ApiRequestService.getRequestUrl(ApiProtocol.REST, config, request);
        String jsonPayload = ApiRequestService.buildJSONPayload(request);

        try {
            RESTApiClient connection = new RESTApiClient();
            String resp = connection.sendTransaction(jsonPayload, requestUrl, config);
            // Redirect to provider's website
            mav.setViewName("redirect:" + ApiResponseService.getBrowserPaymentRedirectUrl(resp));
        } catch (ApiException e) {
            ExceptionService.constructApiErrorResponse(mav, e);
        } catch (Exception e) {
            ExceptionService.constructGeneralErrorResponse(mav, e);
        }
        return mav;
    }


    /**
     * This method handles the response from the CHECK_3DS_ENROLLMENT operation. If the card is enrolled, the response includes the HTML for the issuer's authentication form, to be injected into 3dSecurePayerAuthenticationForm.html.
     * Otherwise, it displays an error.
     *
     * @param request     needed to store 3DSecure ID and session ID in HttpSession
     * @param apiRequest needed to retrieve various data to complete API operation
     * @return ModelAndView - displays issuer authentication form or error page
     */
    @PostMapping("/check3dsEnrollment")
    public ModelAndView check3dsEnrollment(HttpServletRequest request, @RequestBody ApiRequest apiRequest) {

        ModelAndView mav = new ModelAndView();

        try {
            // Retrieve session
            HostedSession session = ApiResponseService.retrieveSession(config, apiRequest.getSessionId());

            // Construct CHECK_3DS_ENROLLMENT API request
            String jsonPayload = ApiRequestService.buildJSONPayload(apiRequest);

            // Create a unique identifier to use for 3DSecure
            String secureId = Utils.createUniqueId("3ds-");

            // Save this value in HttpSession to retrieve after returning from issuer authentication form
            HttpSession httpSession = request.getSession();
            httpSession.setAttribute("secureId", secureId);
            httpSession.setAttribute("sessionId", session.getId());

            String requestUrl = ApiRequestService.getSecureIdRequest(ApiProtocol.REST, config, secureId);

            // Perform API operation
            RESTApiClient apiConnection = new RESTApiClient();
            String apiResponse = apiConnection.sendTransaction(jsonPayload, requestUrl, config);

            SecureIdEnrollmentResponse secureIdEnrollmentResponseObject = ApiResponseService.parse3DSecureResponse(apiResponse);
            secureIdEnrollmentResponseObject.setResponseUrl(ApiRequestService.getCurrentContext(request) + "/process3ds");

            if (secureIdEnrollmentResponseObject.getStatus().equals(ApiResponses.CARD_ENROLLED.toString())) {
                mav.setViewName("3dSecurePayerAuthenticationForm");
                mav.addObject("secureId", secureIdEnrollmentResponseObject);
                mav.addObject("config", config);
            } else {
                mav.setViewName("error");
                mav.addObject("cause", secureIdEnrollmentResponseObject.getStatus());
                mav.addObject("message", "Card not enrolled in 3DS.");
            }
        }
        catch(ApiException e) {
            ExceptionService.constructApiErrorResponse(mav, e);
        }
        catch (Exception e) {
            ExceptionService.constructGeneralErrorResponse(mav, e);
        }

        return mav;
    }

    /**
     * This method completes the 3DS process after the enrollment check. It calls PROCESS_ACS_RESULT, which returns either a successful or failed authentication response.
     * If the response is successful, complete the operation (PAY, AUTHORIZE, etc) or shows an error page.
     *
     * @param request needed to retrieve 3DSecure ID and session ID to complete 3DS transaction
     * @return ModelAndView - displays api response page or error page
     */
    @PostMapping("/process3ds")
    public ModelAndView process3ds(HttpServletRequest request) {

        ModelAndView mav = new ModelAndView();

        ApiRequest req = new ApiRequest();
        req.setApiOperation("PROCESS_ACS_RESULT");
        // Retrieve Payment Authentication Response (PaRes) from request
        req.setPaymentAuthResponse(request.getParameter("PaRes"));

        try {
            HttpSession session = request.getSession();
            String secureId = (String) session.getAttribute("secureId");
            String sessionId = (String) session.getAttribute("sessionId");

            ApiRequestService.updateSessionWithOrderInfo(ApiProtocol.REST, req, config, sessionId);

            // Remove from session after using
            session.removeAttribute("secureId");
            session.removeAttribute("sessionId");

            // Process Access Control Server (ACS) result
            String requestUrl = ApiRequestService.getSecureIdRequest(ApiProtocol.REST, config, secureId);
            RESTApiClient connection = new RESTApiClient();

            String data = ApiRequestService.buildJSONPayload(req);
            String resp = connection.postTransaction(data, requestUrl, config);
            SecureIdEnrollmentResponse secureIdEnrollmentResponseObject = ApiResponseService.parse3DSecureResponse(resp);

            if (!secureIdEnrollmentResponseObject.getStatus().equals(ApiResponses.AUTHENTICATION_FAILED.toString())) {
                // Construct API request
                ApiRequest apiReq = ApiRequestService.createApiRequest("PAY", config);
                apiReq.setSessionId(sessionId);
                apiReq.setSecureId(secureId);

                String payload = ApiRequestService.buildJSONPayload(apiReq);
                String reqUrl = ApiRequestService.getRequestUrl(ApiProtocol.REST, config, apiReq);

                // Perform API operation
                RESTApiClient apiConnection = new RESTApiClient();
                String apiResponse = apiConnection.sendTransaction(payload, reqUrl, config);

                ObjectMapper mapper = new ObjectMapper();
                Object prettyResp = mapper.readValue(apiResponse, Object.class);
                Object prettyPayload = mapper.readValue(payload, Object.class);

                mav.setViewName("apiResponse");
                mav.addObject("resp", mapper.writerWithDefaultPrettyPrinter().writeValueAsString(prettyResp));
                mav.addObject("operation", apiReq.getApiOperation());
                mav.addObject("method", apiReq.getApiMethod());
                mav.addObject("request", mapper.writerWithDefaultPrettyPrinter().writeValueAsString(prettyPayload));
                mav.addObject("requestUrl", reqUrl);
            } else {
                mav.setViewName("error");
                mav.addObject("cause", ApiResponses.AUTHENTICATION_FAILED.toString());
                mav.addObject("message", "3DS authentication failed. Please try again with another card.");
            }
        } catch (ApiException e) {
            ExceptionService.constructApiErrorResponse(mav, e);
        } catch (Exception e) {
            ExceptionService.constructGeneralErrorResponse(mav, e);
        }
        return mav;
    }
}
