package com.gateway.app;

public enum ApiResponses {

    SUCCESS,
    CARD_ENROLLED,
    AUTHENTICATION_FAILED,
    COMPLETED
}
