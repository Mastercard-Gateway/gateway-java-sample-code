# Update this file for setting up Merchant Id and other environmental configurations for the test server

export GATEWAY_MERCHANT_ID=YOUR_MERCHANT_ID
export GATEWAY_API_PASSWORD=YOUR_API_PASSWORD
export GATEWAY_BASE_URL=YOUR_GATEWAY_BASE_URL
java -jar dist/gateway-java-sample-code-1.1.0.jar
