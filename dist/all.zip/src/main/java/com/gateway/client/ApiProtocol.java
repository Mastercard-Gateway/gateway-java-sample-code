package com.gateway.client;

public enum ApiProtocol {
    REST, NVP
}
