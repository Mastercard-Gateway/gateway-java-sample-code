/*
 * Copyright (c) 2019 MasterCard. All rights reserved.
 */

/**
 *    The Hosted Session JavaScript client library enables you to collect sensitive payment details from the payer in
 *    payment form fields, hosted by the Mastercard Payment Gateway. For more information, see {@link https://secure.uat.tnspayments.com/api/documentation/integrationGuidelines/supportedFeatures/pickAdditionalFunctionality/paymentSession.html payment session}
 *    See https://secure.uat.tnspayments.com/api/documentation/integrationGuidelines/hostedSession/integrationModelHostedSession.html Implementing a Hosted Session Integration
 */

// APPLY CLICK-JACKING STYLING AND HIDE CONTENTS OF THE PAGE
if (self === top) {
    var antiClickjack = document.getElementById("antiClickjack");
    if (antiClickjack) antiClickjack.parentNode.removeChild(antiClickjack);
} else {
    top.location = self.location;
}
// The optional named instance of a card payment data set within a session.
// See https://secure.uat.tnspayments.com/api/documentation/integrationGuidelines/hostedSession/integrationModelHostedSession.html?locale=en_US#x_multipleCards
const scope = $(".mb-4")[0].id;

// HOLD THE CALLBACK FUNCTION THAT WILL BE CALLED AFTER THE HOSTED FIELDS IN THE SESSION HAVE BEEN UPDATED
// See pay(callback)
var afterSessionUpdated;
var sessionId = (!$("#session-id")[0]) ? "" : $("#session-id")[0].value;

PaymentSession.configure({
    session: sessionId,
    fields: {
        // ATTACH HOSTED FIELDS TO YOUR PAYMENT PAGE FOR A CREDIT CARD
        card: {
            number: "#card-number",
            securityCode: "#security-code",
            expiryMonth: "#expiry-month",
            expiryYear: "#expiry-year"
        }
    },
    //SPECIFY YOUR MITIGATION OPTION HERE
    frameEmbeddingMitigation: ["javascript"],
    callbacks: {
        initialized: function (response) {
            if (response.status) {
                if ("ok" == response.status) {
                    console.log("Payment Session initialized for scope: " + response.scopeId);
                }
            }
        },
        formSessionUpdate: function (response) {
            // HANDLE RESPONSE FOR UPDATE SESSION
            if (response.status) {
                clearErrorMessages();
                if ("ok" == response.status && finalSubmit == true) {
                    console.log("Session updated with data: " + response.session.id);

                    if (!afterSessionUpdated) {
                        submitFields(response.session.id);
                    } else {
                        afterSessionUpdated();
                    }
                } else if ("fields_in_error" == response.status) {

                    console.log("Session update failed with field errors.");

                    if (response.errors.cardNumber) {
                        handleError("Card number missing or invalid.");
                    }
                    if (response.errors.expiryYear) {
                        handleError("Expiry year missing or invalid.");
                    }
                    if (response.errors.expiryMonth) {
                        handleError("Expiry month missing or invalid.");
                    }
                    if (response.errors.securityCode) {
                        handleError("Security code invalid.");
                    }
                } else if ("request_timeout" == response.status) {
                    handleError("Session update failed with request timeout: " + response.errors.message);
                } else if ("system_error" == response.status) {
                    handleError("Session update failed with system error: " + response.errors.message)
                }
                finalSubmit = false;
            } else {
                handleError("Session update failed: " + response);
                finalSubmit = false;
            }
        }
    }
}, scope);

PaymentSession.setFocus('card.number', scope);

function pay(callback) {
    $("#loading-bar-spinner").show();
    finalSubmit = true;
    expiryMonth = expiryYear = cardNumber = securityCode = false;

    // UPDATE CALLBACK FUNCTION THAT WILL BE CALLED ONCE THE SESSION HAS BEEN UPDATED
    if (callback)
        afterSessionUpdated = callback;

    // UPDATE THE SESSION WITH THE INPUT FROM HOSTED FIELDS
    // USAGE PaymentSession.updateSessionFromForm(paymentType, [scope])
    PaymentSession.updateSessionFromForm('card', null, scope);
}

function submitFields(sessionId) {
    var data = {
        apiOperation: JavaSample.operation(),
        sessionId: sessionId,
        transactionId: $('#transaction-id').val(),
        orderId: $('#order-id').val(),
        orderAmount: $('#order-amount').val(),
        orderCurrency: $('#order-currency').val(),
        orderDescription: $('#order-description').val(),
        secureIdResponseUrl: JavaSample.secureIdResponseUrl()
    };

    var xhr = new XMLHttpRequest();
    xhr.open('POST', JavaSample.endpoint(), true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.onreadystatechange = function () {
        if (xhr.readyState == XMLHttpRequest.DONE) {
            document.documentElement.innerHTML = this.response;
        }
    };
    xhr.send(JSON.stringify(data));
}

function handleError(message) {
    $("#loading-bar-spinner").hide();
    var $errorAlert = $('#error-alert');
    console.log(message);
    $errorAlert.append("<p>" + message + "</p>");
    $errorAlert.show();
}

function clearErrorMessages(){
    var $errorAlert = $('#error-alert');
    $errorAlert.html("");
    $errorAlert.hide();
}